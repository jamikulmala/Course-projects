"""
comp.cs.100
Tekijä: Jami Kulmala
Opiskelijanumero: 150425043

Ohjelma mallintaa squid game televisiosarjasta tuttua marmorikuulilla pelattavaa
odds and evens peliä.
"""

# Kun avaa ohjelman avautuu valikko, jossa kohdasta play pääsee itse peliin.
# Instructions kohdasta löytyy ohjeet sekä suomeksi, että englanniksi.
# Itse pelissä on ideana voittaa kaikki pelissä olevat kuulat.
# ensin valitaan kuulien kokonais määrä pelissä,
# sitten toinen pelaaja päättää montako kuulaa ottaa käteensä, ja toinen arvaa onko kuulien määrä
# parillinen vai pariton. Käytännössä se toimisi niin, että pelatessa, kuulat kädessä oleva,
# piiloittaisi aina esimerkiksi sormella tai lapulla valitsemansa luvun,
# jotta arvaamisessa olisi järkeä. Kun molemmat pelaajat ovat tehneet valintansa painetaan submit,
# josta valinnat lukitaan ja kuulat vaihtavat omistajaansa. Jos toinen pelaaja arvaa oikein onko
# luku parillinen vai pariton, saa hän toisen pelaajan kädessä olleen kuulien määrän itselleen.
# Jos hän arvaa väärin, joutuu hän itse antamaan kädessä olleen määrän kuulia vastustajalle.
# peli päättyy kun jommankumman pelaajan kuulat loppuvat. Vuoron vaihto tapahtuu change turn
# painikkeesta. Lukittuna ovat aina ne kentät joihin ei voi syöttää, mitään eli käytännössä
# Jos on pelaajan yksi vuoro arvata, hän ei voi syöttää kuulien määrää vaan ainoastaan odd/even.
# Alareunassa oleva palkki ohjeistaa pelaajia, esimerkiksi kertoo kumman vuoro on syöttää
# mikäkin vuoro. Se myös reagoi virheellisiin syötteisiin esimerkiksi kuulien määrän ollessa liian
# suuri tai vääriin syötteisiin ja pyytää virheen tekijää yrittämään uudelleen. Myös pelin
# päättyessä palkki ilmoittaa pelin voittajan ja pelin kentät lukittuvat. Uuden pelin
# voi aloittaa milloin vain return menu painikkeesta, jolloin käyttäjä palaa alun valikkoon
# ja peli nollaantuu. Painamalla quit valikossa ohjelma pysähtyy.

# Ohjelmaa tähtää kehittyneeseen versioon projektista.

from tkinter import *
from winsound import *

# pelin kaksi pelaajaa
player1 = 1
player2 = 2

class UI:

    def __init__(self):
        # pitää kirjaa esimerkiksi kuulien kokonaismäärästä, pelaajien kuulien määrästä,
        # vastauksista ja arvauksista.
        self.__paaikkuna = Tk()
        self.__paaikkuna.geometry("500x400")
        self.kuulat = 0
        self.player1kuulat = 0
        self.player2kuulat = 0
        self.p1answer = ""
        self.p2answer = ""
        self.p1hand = ""
        self.p2hand = ""
        self.__whose_turn = player1

        # asetetaan taustakuva tyllin vuoksi valikkoon
        background_image = PhotoImage(file = "bg.gif")

        # taustakuvan asettaminen
        self.background = Label(self.__paaikkuna, image=background_image)
        self.background.place(x=0, y=0, relwidth=1, relheight=1)

        # pelin nimi otsikoksi
        self.__title = Label(self.__paaikkuna, text = "Odds and Evens",bd = 10,
        relief = GROOVE, font = ("Abadi MT Condensed Extra Bold", "45"), bg = "pink", fg = "white")
        self.__title.pack(side=TOP)

        # play nappi, josta peli käynnistyy
        self.__playbutton = Button(self.__paaikkuna, text = "Play", command = self.start_game, bd = 5,
        relief = GROOVE, font = ("times new roman", "25"), bg ="white", fg ="pink",activebackground = "red" )
        self.__playbutton.pack()

        # instructions nappi, josta pääsee ohjeisiin
        self.__instructions = Button(self.__paaikkuna, text = "Instructions", bd = 5, command = self.avaa_ohjeet,
        relief = GROOVE, font = ("times new roman","25"), bg = "white", fg = "pink", activebackground = "red")
        self.__instructions.pack()

        # quit nappi, josta ohjelma pysähtyy
        self.__quit = Button(self.__paaikkuna, text = "Quit", bd= 5, command = self.exit,
        relief = GROOVE, font = ("times new roman", "25"), bg = "white", fg = "pink", activebackground = "red")
        self.__quit.pack()

        self.__paaikkuna.mainloop()

    def exit(self):
        """
        lopettaa ohjelman
        :return: nothing
        """
        self.__paaikkuna.destroy()
        exit()

    def avaa_ohjeet(self):
        """
        avaa ohjeet ikkunan
        :return: nothing
        """
        ohjeet = Toplevel()

        ohjeet.title("Instructions")

        ohjeet.geometry("500x400")

        ohjeet.configure(background = "pink")

        # ohjeet pelin pelaamiseen
        self.ohjeet = Label(ohjeet, text = "- The objective of the game is to collect all the marbles.\n"
        "- Two players will distribute all the marbles in the game, \nwhich must be an even number.\n"
        "- For example if there's 20 marbles in the game, each player gets 10.\n""-The other player chooses"
        " an amount of marbles to hold in their hand\n  and the other tries to guess whether the amount is even or no.\n"
        "- If the player guesses right, he/she gets all the marbles in the hand.\n- If the player is wrong the player"
        " guessing must give\n the amount of marbles in the hand to the other player.\n" 
        " - The winner will be the player who wins all the marbles in the game",
        font = ("times new roman", "11"), bg = "white", fg = "black")
        self.ohjeet.pack()

        # nappi, joka muuttaa ohjeet englanniksi
        self.english = Button(ohjeet, text="In english", command = self.englanti, bg = "white", fg = "blue",
        font = ("arial", "20"), state=DISABLED)
        self.english.pack(side=BOTTOM)

        # nappi, joka muuttaa ohjeet suomeksi
        self.finnish = Button(ohjeet, text="Suomeksi", command=self.suomi, bg="white", fg="blue",
        font=("arial", "20"), state=NORMAL)
        self.finnish.pack(side=BOTTOM)

        # nappi, joka palauttaa käyttäjän valikkoon
        self.palaa = Button(ohjeet, text="Return", command = ohjeet.destroy, bg = "white", fg ="black",
        font = ("arial", "20"))
        self.palaa.pack(side=BOTTOM)

        ohjeet.mainloop()

    def suomi(self):
        """
        Ohjeet suomeksi
        :return: nothing
        """
        self.ohjeet["text"] = "- Pelin tavoitteena on kerätä kaikki marmorit.\n- Kaksi pelaajaa jakavat" \
        "pelissä olevat marmorit, määrän täytyy olla parillinen.\n- Esimerkiksi, jos pelissä on 20 marmoria" \
        "kumpikin pelaaja saa 10.\n- Toinen pelaaja päättää montako pitää nyrkissään\nja toinen yrittää arvata" \
        "onko määrä parillinen vai pariton.\n- Jos pelaaja vastaa oikein hän saa niin monta marmoria itselleen," \
        "kun kädessä oli.\n- Jos pelaaja vastaa väärin joutuu hän itse antamaan osoitetun määrän vastustajalle.\n" \
        "- Voittaja on se pelaaja, joka kerää ensimmäisenä kaikki pelin marmorit itselleen."
        self.finnish.configure(state=DISABLED)
        self.english.configure(state=NORMAL)

    def englanti(self):
        """
        ohjeet englanniksi
        :return: nothing
        """
        self.ohjeet["text"] = "- The objective of the game is to collect all the marbles.\n" \
        "- Two players will distribute all the marbles in the game, \nwhich must be an even number.\n" \
        "- For example if there's 20 marbles in the game, each player gets 10.\n""-The other player chooses" \
        " an amount of marbles to hold in their hand\n  and the other tries to guess whether the amount is even or no.\n" \
        "- If the player guesses right, he/she gets all the marbles in the hand.\n- If the player is wrong the player" \
        " guessing must give\n the amount of marbles in the hand to the other player.\n" \
        " - The winner will be the player who wins all the marbles in the game"
        self.finnish.configure(state=NORMAL)
        self.english.configure(state=DISABLED)

    def start_game(self):
        """
        aloittaa pelin
        :return: nothing
        """

        peli = Toplevel()

        peli.title("Game")

        peli.geometry("1200x599")

        background_image = PhotoImage(file="faceoff.gif")

        peli.background = Label(peli, image=background_image)
        peli.background.place(x=0, y=0, relwidth=1, relheight=1)

        # Musiikit käynnistyvät, kun peli alkaa
        PlaySound("squid_game.wav", SND_ALIAS | SND_ASYNC | SND_LOOP)

        peli.columnconfigure(1, weight = 1)
        peli.rowconfigure(1, weight = 1)

        # palaa valikkoon, voi myös käyttää, jos haluaa aloittaa uuden pelin
        self.paluu = Button(peli, text="Return to menu", command = lambda:(self.returnmenu(), peli.destroy()),
        font = ("arial","20"), bg = "black", fg = "white")
        self.paluu.grid(sticky = SW)

        # näyttää valitun määrän kuulia pelissä
        self.kuulatpelissa = Label(peli, text= f"{self.get_marbles()}",
        font=("arial", "30"), bg = "white", fg = "black")
        self.kuulatpelissa.grid(row = 0, column = 1, sticky = N)

        # ohjeistaa käyttäjää valitsemaan kuulien määrän
        self.kuulalabel = Label(peli, text ="Select the total amount of marbles in the game",
        font=("arial", "20"), bg="white", fg="pink")
        self.kuulalabel.grid(row = 1, column = 1, sticky = N)

        # vaihtoehtona 10, 20 tai 50 kuulaa pelissä
        self.__button1 = Button(peli, text = "10", command = self.marbles_ingame1, font=("arial", "15"),
        state = NORMAL)
        self.__button2 = Button(peli, text = "20", command = self.marbles_ingame2, font=("arial", "15"),
        state = NORMAL)
        self.__button3 = Button(peli, text = "50", command = self.marbles_ingame3, font=("arial", "15"),
        state = NORMAL)
        self.__button1.grid(row = 2, column = 1, sticky = N)
        self.__button2.grid(row = 3, column = 1, sticky = N)
        self.__button3.grid(row = 4, column = 1, sticky = N)

        # osoittaa kummallako puolella on pelaaja1 ja kummalla pelaaja2
        self.__playername1 = Label(peli, text = "Player1:", font = ("Arial", "15"))
        self.__playername2 = Label(peli, text = "Player2:", font = ("Arial", "15"))
        self.__playername1.grid(row = 4, column = 0, sticky = W)
        self.__playername2.grid(row = 4, column = 2, sticky = E)

        # näyttää pelaajien kuulatilanteet
        self.pelaaja1kuulat = Label(peli, text = f"{self.get_player1()}",
        font=("arial", "25"), bg = "white", fg = "black")
        self.pelaaja1kuulat.grid(row = 5, column = 0, sticky = W)

        self.pelaaja2kuulat = Label(peli, text = f"{self.get_player2()}",
        font=("arial", "25"), bg = "white", fg = "black")
        self.pelaaja2kuulat.grid(row = 5, column = 2, sticky = E)

        # näihin käyttäjät syöttävät kädessä olevat kuulat ja arvauksensa
        self.onehand = Entry(peli, state = NORMAL)
        self.onehand.grid(row = 6, column = 0, sticky = W)
        self.twohand = Entry(peli, state = DISABLED)
        self.twohand.grid(row = 6, column = 2, sticky = E)
        self.oneguess = Entry(peli, state = DISABLED)
        self.oneguess.grid(row = 7, column = 0, sticky = W)
        self.twoguess = Entry(peli, state = NORMAL)
        self.twoguess.grid(row = 7, column = 2, sticky = E)

        # ohjaa pelin kulkua ja raportoi virheistä
        self.log = Label(peli, text = "Choose amount of marbles. "
        "Player1 enter the marbles in your hand. Player2 make a guess odd/even. Submit and change turn.",
        font=("Arial", "12"),bg = "white",fg ="black")
        self.log.grid(row = 8, column = 1, sticky = SW)

        # valinnat lukittuvat ja pelaajien kuulien määrä päivitetään
        self.submitbutton = Button(peli, text = "Submit", font=("Arial","14"), bg = "black", fg = "white",
        command = self.game)
        self.submitbutton.grid(row = 8, column = 2, sticky = SE)

        # napista voi vaihtaa pelaajien vuoroa
        self.change_turn_button = Button(peli, text = "change turn", font=("Arial", "14"), bg = "black",
        fg = "white", command = self.change_turn)
        self.change_turn_button.grid(row=8, column = 0, sticky = SW)

        peli.mainloop()


    def check_for_win(self):
        """
        tarkastelee pelaajien kuulien määrää ja ilmoittaa jos jompikumpi voittaa
        :return: True, jos jompikumpi pelaaja on voittanut, False jos ei
        """
        # verrataan pelaajien kuulien määrää kaikkiin kuuliin
        if self.player1kuulat >= self.kuulat or self.player2kuulat >= self.kuulat:
            # tarkastetaan kumpi on voittaja
            if self.player1kuulat > self.player2kuulat:
              self.log["text"] = "Player 1 won! Return to menu"
            else:
              self.log["text"] = "Player 2 won! Return to menu"

            # jommankumman pelaajan voittaessa syöttökentät deaktivoituvat
            self.onehand.configure(state=DISABLED)
            self.twohand.configure(state=DISABLED)
            self.oneguess.configure(state=DISABLED)
            self.twoguess.configure(state=DISABLED)

            return True
        else:
            return False

    def returnmenu(self):
        """
        nollaa pelin
        :return: nothing
        """
        self.kuulat = 0
        self.player1kuulat = 0
        self.player2kuulat = 0
        self.__whose_turn = player1
        self.update_ui()


    def marbles_ingame1(self):
        """
        10 kuulan pelin valinta
        :return: nothing
        """
        self.kuulat += 10
        self.__button1.configure(state=DISABLED)
        self.__button2.configure(state=DISABLED)
        self.__button3.configure(state=DISABLED)
        self.player1kuulat += 10 // 2
        self.player2kuulat += 10 // 2
        self.update_ui()


    def marbles_ingame2(self):
        """
        20 kuulan pelin valinta
        :return: nothing
        """
        self.kuulat += 20
        self.__button1.configure(state=DISABLED)
        self.__button2.configure(state=DISABLED)
        self.__button3.configure(state=DISABLED)
        self.player1kuulat = 20 // 2
        self.player2kuulat = 20 // 2
        self.update_ui()


    def marbles_ingame3(self):
        """
        50 kuulan pelin valinta
        :return: nothing
        """
        self.kuulat += 50
        self.__button1.configure(state=DISABLED)
        self.__button2.configure(state=DISABLED)
        self.__button3.configure(state=DISABLED)
        self.player1kuulat = 50//2
        self.player2kuulat = 50//2
        self.update_ui()

    def update_ui(self):
        """
        Päivittää käyttöliittymän
        :return: nothing
        """
        self.kuulatpelissa["text"] = f"{self.get_marbles()}"
        self.pelaaja1kuulat["text"] = f"{self.get_player1()}"
        self.pelaaja2kuulat["text"] = f"{self.get_player2()}"

    def get_marbles(self):
        """
        hakee pelissä olevien kuulien määrän
        :return: self.kuulat, pelissä olevien kuulien määrä.
        """
        return self.kuulat

    def get_player1(self):
        """
        hakee pelaajan yksi kuulat. Tässä vielä lisänä virhetarkastelut.
        :return: pelaajan 1 kuulien määrä
        """
        if 0 <= self.player1kuulat <= self.kuulat:
            return self.player1kuulat
        elif self.player1kuulat < 0:
            return 0
        elif self.player1kuulat > self.kuulat:
            return self.kuulat

    def get_player2(self):
        """
        hakee pelaajan yksi kuulat. Tässä vielä lisänä virhetarkastelut.
        :return: pelaajan 2 kuulien määrä
        """
        if 0 <= self.player2kuulat <= self.kuulat:
            return self.player2kuulat
        elif self.player2kuulat < 0:
            return 0
        elif self.player2kuulat > self.kuulat:
            return self.kuulat

    def hae_lahtoarvot(self):
        """
        hakee syötetyt arvot
        :return: a_arvo, b_arvo
        """
        # kuulien syöttövuoron ollessa pelaajalla kaksi
        if self.__whose_turn == player2:
            a_arvo = self.twohand.get()
            b_arvo = self.oneguess.get()
            return (a_arvo, b_arvo)

        # kuulien syöttövuoron ollessa pelaajalla yksi
        elif self.__whose_turn == player1:
            a_arvo = self.onehand.get()
            b_arvo = self.twoguess.get()
            return (a_arvo, b_arvo)

        else: return None

    def change_turn(self):
        """
        vaihtaa pelaaien syöttövuotot
        :return: none
        """
        # vuoron ollessa pelaaja ykkösellä vaihdetaan vuoro pelaaja kahdelle vice versa
        # päivitetään log antamaan ohjeet aina toiselle pelaajalle ja muutetaan entryjen
        # tilat deaktiivisiksi tai aktiivisiksi
        if self.__whose_turn == player1:
            self.__whose_turn = player2
            self.log["text"] = "Player 2 enter the amount of marbles in your hand." \
            "Player 1 make a guess odd/even. Submit and change turn when ready."
            self.onehand.configure(state=DISABLED)
            self.twohand.configure(state=NORMAL)
            self.oneguess.configure(state=NORMAL)
            self.twoguess.configure(state=DISABLED)
        else:
            self.__whose_turn = player1
            self.log["text"] = "Player 1 enter the amount of marbles in your hand." \
            "Player 2 make a guess odd/even. Submit and change turn when ready."
            self.onehand.configure(state=NORMAL)
            self.twohand.configure(state=DISABLED)
            self.oneguess.configure(state=DISABLED)
            self.twoguess.configure(state=NORMAL)


    def game(self):
        """
        Pelaajien kuulat päivitetään. Sitä hyödynnetään painaessa submit näppäintä.
        Itse peli tapahtuu siis käytännössä tässä metodissa.
        :return:
        """
        # tarkastetaan onko kuulien kokonaismäärä valittu
        if self.kuulat > 0:

            # vuoron ollessa pelaaja ykkösellä toteutetaan tämä
            if self.__whose_turn == player1:
                # haetaan käyttäjien syötteet ja nimetään ne a ja b
                (a, b) = self.hae_lahtoarvot()

                try:
                    # a tulee olla positiivinen kokonaisluku ja b:ksi kelpuutetaan
                    # vain sanat odd ja even ja ei voida lyödä vetoa enemmistä
                    # kuulista mitä käyttäjällä on.
                    a = int(a)
                    if a > 0:
                        if b in ("odd", "Odd", "ODD", "even", "Even", "EVEN"):
                            if a <= self.player1kuulat:

                                b = b.strip()

                                # tarkistetaan onko vastaus parillinen vai pariton, jos pelaaja
                                # on arvaanut oikein esim a = 2 ja b = even saa hän a määrän
                                # kuulia itselleen. Jos vastaa väärin eli odd menettää hän kuulat itse.
                                if int(a) % 2 == 0:
                                    vastaus = "even"
                                    if b == vastaus:
                                        self.player1kuulat -= int(a)
                                        self.player2kuulat += int(a)
                                    else:
                                        self.player1kuulat += int(a)
                                        self.player2kuulat -= int(a)

                                elif int(a) % 2 != 0:
                                    vastaus = "odd"
                                    if b == vastaus:
                                        self.player1kuulat -= int(a)
                                        self.player2kuulat += int(a)
                                    else:
                                        self.player1kuulat += int(a)
                                        self.player2kuulat -= int(a)

                                # päivitetään käyttöliittymä ja tarkastetaan onko jompikumpi
                                # voittanut
                                self.update_ui()

                                self.check_for_win()

                # asioiden mennessä pieleen alhaalla näkyvään palkkiin ilmestyy ilmoitus, mitä meni vikaan
                # ja käyttäjät voivat yrittää uudelleen.

                            else: self.log["text"] = "You cannot bet more marbles than you have left"
                        else: self.log["text"] = "You must guess either odd or even, please try again"
                    else: self.log["text"] = "Amount of marbles in the hand must be positive, please enter a positive integer."
                except: self.log["text"] = "Amount of marbles in the hand must be an integer, please try again."

            # vuoron ollessa pelaajalla kaksi toteutetaan tämö. Erona edelliseen on muutettu
            # kuulien lisäykset ja vähennykset + ja -, jotta ne toimivat oikein
            else:
                (a, b) = self.hae_lahtoarvot()

                try:
                    a = int(a)
                    if a > 0:
                        if b in ("odd", "Odd", "ODD", "even", "Even", "EVEN"):
                            if a <= self.player1kuulat:

                                b = b.strip()

                                if int(a) % 2 == 0:
                                    vastaus = "even"
                                    if b == vastaus:
                                        self.player1kuulat += int(a)
                                        self.player2kuulat -= int(a)
                                    else:
                                        self.player1kuulat -= int(a)
                                        self.player2kuulat += int(a)

                                elif int(a) % 2 != 0:
                                    vastaus = "odd"
                                    if b == vastaus:
                                        self.player1kuulat += int(a)
                                        self.player2kuulat -= int(a)
                                    else:
                                        self.player1kuulat -= int(a)
                                        self.player2kuulat += int(a)

                                self.update_ui()

                                self.check_for_win()

                            else: self.log["text"] = "You cannot bet more marbles than you have left"
                        else: self.log["text"] = "You must guess either odd or even, please try again"
                    else: self.log["text"] = "Amount of marbles in the hand must be positive, please enter a positive integer."
                except: self.log["text"] = "Amount of marbles in the hand must be an integer, please try again."

        else:
            self.log["text"] = "The amount of marbles in the game must be greater than zero, " \
            "please choose the amount of marbles in the game first 10/20/50."

def main():
    UI()


if __name__ == "__main__":
    main()